# COT loader placeholder
