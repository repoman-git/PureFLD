# MeridianConfig placeholder with SeasonalityConfig
