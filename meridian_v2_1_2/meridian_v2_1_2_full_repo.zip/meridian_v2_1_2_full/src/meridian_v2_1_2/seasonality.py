import pandas as pd
def compute_tdom_flags(index,favourable_days,unfavourable_days):
    return pd.Series([1 if d.day in favourable_days else -1 if d.day in unfavourable_days else 0 for d in index], index=index)
