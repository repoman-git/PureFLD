# Strategy placeholder
