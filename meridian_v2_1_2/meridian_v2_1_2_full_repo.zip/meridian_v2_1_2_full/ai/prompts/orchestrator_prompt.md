# AI orchestrator prompt placeholder
